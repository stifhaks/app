//FireBase -- REPLACE WITH YOUR VALUES
// Initialize Firebase
var firebaseConfig = {
  apiKey: "AIzaSyCH6wmL18AbDqCIXNsGBGINxzUnlPkB3bs",
  authDomain: "universalapp-a272a.firebaseapp.com",
  databaseURL: "https://universalapp-a272a.firebaseio.com",
  projectId: "universalapp-a272a",
  storageBucket: "universalapp-a272a.appspot.com",
  messagingSenderId: "35001014547"
};
  
exports.config = firebaseConfig;
